// App.js — AzərPoçt Ana Tətbiq
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import HomeScreen from './src/screens/HomeScreen';
import TrackingScreen from './src/screens/TrackingScreen';
import TrackingDetailScreen from './src/screens/TrackingDetailScreen';
import ChatbotScreen from './src/screens/ChatbotScreen';
import PaymentScreen from './src/screens/PaymentScreen';
import BranchMapScreen from './src/screens/BranchMapScreen';

const Tab = createBottomTabNavigator();
const TrackStack = createStackNavigator();

const COLORS = {
  primary: '#1A3A5C',
  accent: '#E63946',
  bg: '#F8F9FC',
};

function TrackingStack() {
  return (
    <TrackStack.Navigator screenOptions={{ headerShown: false }}>
      <TrackStack.Screen name="TrackingMain" component={TrackingScreen} />
      <TrackStack.Screen name="TrackingDetail" component={TrackingDetailScreen} />
    </TrackStack.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar backgroundColor={COLORS.primary} barStyle="light-content" />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            tabBarActiveTintColor: COLORS.accent,
            tabBarInactiveTintColor: '#888',
            tabBarStyle: {
              backgroundColor: '#fff',
              borderTopWidth: 0,
              elevation: 12,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: -4 },
              shadowOpacity: 0.08,
              shadowRadius: 12,
              height: 62,
              paddingBottom: 8,
              paddingTop: 6,
            },
            tabBarLabelStyle: {
              fontSize: 11,
              fontWeight: '600',
            },
            tabBarIcon: ({ color, size, focused }) => {
              const icons = {
                Home: focused ? 'home' : 'home-outline',
                Tracking: focused ? 'package-variant-closed' : 'package-variant-closed',
                Chatbot: focused ? 'robot' : 'robot-outline',
                Payment: focused ? 'credit-card' : 'credit-card-outline',
                Branches: focused ? 'map-marker' : 'map-marker-outline',
              };
              return <Icon name={icons[route.name]} size={size} color={color} />;
            },
          })}
        >
          <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarLabel: 'Ana Səhifə' }} />
          <Tab.Screen name="Tracking" component={TrackingStack} options={{ tabBarLabel: 'Bağlama' }} />
          <Tab.Screen name="Chatbot" component={ChatbotScreen} options={{ tabBarLabel: 'Köməkçi' }} />
          <Tab.Screen name="Payment" component={PaymentScreen} options={{ tabBarLabel: 'Ödəniş' }} />
          <Tab.Screen name="Branches" component={BranchMapScreen} options={{ tabBarLabel: 'Filiallar' }} />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
