// src/screens/TrackingDetailScreen.js
import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const mockDetail = {
  AZ123456789: {
    id: 'AZ123456789',
    status: 'Çatdırılır',
    statusCode: 'delivering',
    from: 'Çin (Şənhay)',
    to: 'Bakı, Nizami r-nu',
    weight: '1.2 kq',
    estimatedDate: '27 Apr 2026',
    events: [
      { time: '25 Apr, 14:30', location: 'Bakı Poçt Mərkəzi', desc: 'Çatdırılma üçün kuryerə verildi', done: true, active: true },
      { time: '24 Apr, 09:15', location: 'Bakı Beynəlxalq Hava Limanı', desc: 'Gömrük rəsmiləşdirilməsi tamamlandı', done: true, active: false },
      { time: '22 Apr, 18:00', location: 'Bakı Hava Limanı', desc: 'Azərbaycana çatdı', done: true, active: false },
      { time: '20 Apr, 11:20', location: 'Şənhay, Çin', desc: 'Göndərmə poçtundan çıxdı', done: true, active: false },
      { time: '19 Apr, 16:45', location: 'Şənhay, Çin', desc: 'Bağlama göndərməyə qəbul edildi', done: true, active: false },
    ],
  },
};

const defaultDetail = {
  id: '',
  status: 'Tapılmadı',
  statusCode: 'waiting',
  from: '—',
  to: '—',
  weight: '—',
  estimatedDate: '—',
  events: [],
};

export default function TrackingDetailScreen({ navigation, route }) {
  const { trackId } = route.params || {};
  const detail = mockDetail[trackId] || { ...defaultDetail, id: trackId };

  const statusColors = {
    delivering: '#059669',
    customs: '#D97706',
    delivered: '#6B7280',
    waiting: '#2563EB',
  };
  const color = statusColors[detail.statusCode] || '#2563EB';

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1A3A5C', '#2563EB']} style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Bağlama Detalları</Text>
        <View style={{ width: 40 }} />
      </LinearGradient>

      <ScrollView style={styles.body} showsVerticalScrollIndicator={false}>
        
        {/* Main Card */}
        <View style={styles.mainCard}>
          <View style={styles.idRow}>
            <Text style={styles.idText}>{detail.id}</Text>
            <View style={[styles.badge, { backgroundColor: color + '18' }]}>
              <Text style={[styles.badgeText, { color }]}>{detail.status}</Text>
            </View>
          </View>

          <View style={styles.routeRow}>
            <View style={styles.routePoint}>
              <Icon name="circle" size={10} color="#2563EB" />
              <Text style={styles.routeLabel}>Göndərən</Text>
              <Text style={styles.routeValue}>{detail.from}</Text>
            </View>
            <View style={styles.routeDash}>
              <View style={styles.dashLine} />
              <Icon name="airplane" size={16} color="#94A3B8" />
              <View style={styles.dashLine} />
            </View>
            <View style={styles.routePoint}>
              <Icon name="map-marker" size={10} color="#E63946" />
              <Text style={styles.routeLabel}>Alan</Text>
              <Text style={styles.routeValue}>{detail.to}</Text>
            </View>
          </View>

          <View style={styles.infoGrid}>
            <View style={styles.infoCell}>
              <Icon name="weight" size={16} color="#94A3B8" />
              <Text style={styles.infoCellLabel}>Çəki</Text>
              <Text style={styles.infoCellValue}>{detail.weight}</Text>
            </View>
            <View style={styles.infoSep} />
            <View style={styles.infoCell}>
              <Icon name="calendar-clock" size={16} color="#94A3B8" />
              <Text style={styles.infoCellLabel}>Gözlənilən tarix</Text>
              <Text style={styles.infoCellValue}>{detail.estimatedDate}</Text>
            </View>
          </View>
        </View>

        {/* Timeline */}
        <Text style={styles.sectionTitle}>Hərəkət Tarixi</Text>
        <View style={styles.timelineCard}>
          {detail.events.length === 0 ? (
            <Text style={{ color: '#94A3B8', textAlign: 'center', padding: 20 }}>
              Məlumat tapılmadı
            </Text>
          ) : (
            detail.events.map((event, i) => (
              <View key={i} style={styles.timelineItem}>
                <View style={styles.timelineLeft}>
                  <View style={[styles.dot, {
                    backgroundColor: event.active ? color : (event.done ? '#E2E8F0' : '#E2E8F0'),
                    borderColor: event.active ? color : (event.done ? '#94A3B8' : '#E2E8F0'),
                  }]}>
                    {event.active && <View style={[styles.dotInner, { backgroundColor: '#fff' }]} />}
                    {event.done && !event.active && <Icon name="check" size={10} color="#94A3B8" />}
                  </View>
                  {i < detail.events.length - 1 && (
                    <View style={[styles.line, { backgroundColor: event.done ? '#94A3B8' : '#E2E8F0' }]} />
                  )}
                </View>
                <View style={styles.timelineRight}>
                  <Text style={[styles.eventDesc, { color: event.active ? '#1E293B' : '#64748B', fontWeight: event.active ? '700' : '500' }]}>
                    {event.desc}
                  </Text>
                  <Text style={styles.eventLocation}>{event.location}</Text>
                  <Text style={styles.eventTime}>{event.time}</Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionBtn}>
            <Icon name="bell-ring-outline" size={18} color="#2563EB" />
            <Text style={[styles.actionBtnText, { color: '#2563EB' }]}>Bildiriş Al</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#2563EB' }]}>
            <Icon name="headset" size={18} color="#fff" />
            <Text style={[styles.actionBtnText, { color: '#fff' }]}>Dəstək</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: {
    paddingTop: 48,
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backBtn: { padding: 4 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  body: { flex: 1, padding: 16 },
  mainCard: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 18,
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
  },
  idRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  idText: { fontSize: 16, fontWeight: '800', color: '#1E293B', letterSpacing: 0.5 },
  badge: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  badgeText: { fontSize: 12, fontWeight: '700' },
  routeRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  routePoint: { flex: 1, gap: 4 },
  routeLabel: { fontSize: 11, color: '#94A3B8', fontWeight: '600', marginTop: 4 },
  routeValue: { fontSize: 13, color: '#1E293B', fontWeight: '600' },
  routeDash: { flexDirection: 'row', alignItems: 'center', flex: 0.8, paddingHorizontal: 8 },
  dashLine: { flex: 1, height: 1, backgroundColor: '#E2E8F0' },
  infoGrid: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 14 },
  infoCell: { flex: 1, alignItems: 'center', gap: 4 },
  infoSep: { width: 1, backgroundColor: '#F1F5F9' },
  infoCellLabel: { fontSize: 11, color: '#94A3B8', fontWeight: '600' },
  infoCellValue: { fontSize: 14, color: '#1E293B', fontWeight: '700' },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#1E293B', marginBottom: 12 },
  timelineCard: { backgroundColor: '#fff', borderRadius: 18, padding: 18, marginBottom: 16, elevation: 2 },
  timelineItem: { flexDirection: 'row', marginBottom: 0 },
  timelineLeft: { alignItems: 'center', marginRight: 14, width: 20 },
  dot: {
    width: 20, height: 20, borderRadius: 10,
    borderWidth: 2, justifyContent: 'center', alignItems: 'center',
  },
  dotInner: { width: 8, height: 8, borderRadius: 4 },
  line: { width: 2, flex: 1, minHeight: 24, marginVertical: 3 },
  timelineRight: { flex: 1, paddingBottom: 20 },
  eventDesc: { fontSize: 13, lineHeight: 18 },
  eventLocation: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  eventTime: { fontSize: 11, color: '#CBD5E1', marginTop: 2 },
  actions: { flexDirection: 'row', gap: 12 },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, padding: 14, borderRadius: 14,
    borderWidth: 1.5, borderColor: '#2563EB',
  },
  actionBtnText: { fontSize: 14, fontWeight: '700' },
});
