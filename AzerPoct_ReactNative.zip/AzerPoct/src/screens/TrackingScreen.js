// src/screens/TrackingScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  FlatList, StatusBar,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const mockPackages = [
  {
    id: 'AZ123456789',
    status: 'Çatdırılır',
    statusCode: 'delivering',
    from: 'Çin',
    weight: '1.2 kq',
    date: '25 Apr 2026',
    progress: 75,
  },
  {
    id: 'AZ987654321',
    status: 'Gömrükdə',
    statusCode: 'customs',
    from: 'Türkiyə',
    weight: '0.8 kq',
    date: '23 Apr 2026',
    progress: 45,
  },
  {
    id: 'AZ456789123',
    status: 'Çatdırıldı',
    statusCode: 'delivered',
    from: 'ABŞ',
    weight: '2.5 kq',
    date: '20 Apr 2026',
    progress: 100,
  },
];

const statusConfig = {
  delivering: { color: '#059669', bg: '#D1FAE5', icon: 'truck-delivery' },
  customs: { color: '#D97706', bg: '#FEF3C7', icon: 'shield-check' },
  delivered: { color: '#6B7280', bg: '#F3F4F6', icon: 'check-circle' },
  waiting: { color: '#2563EB', bg: '#DBEAFE', icon: 'clock-outline' },
};

export default function TrackingScreen({ navigation }) {
  const [query, setQuery] = useState('');

  const filtered = mockPackages.filter(p =>
    p.id.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1A3A5C', '#2563EB']} style={styles.header}>
        <Text style={styles.headerTitle}>Bağlama İzlə</Text>
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <Icon name="magnify" size={20} color="#94A3B8" />
            <TextInput
              style={styles.searchInput}
              placeholder="İzləmə nömrəsi..."
              placeholderTextColor="#94A3B8"
              value={query}
              onChangeText={setQuery}
            />
          </View>
          <TouchableOpacity style={styles.scanBtn}>
            <Icon name="barcode-scan" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <Text style={styles.listTitle}>Bağlamalarım ({filtered.length})</Text>
        }
        renderItem={({ item }) => {
          const cfg = statusConfig[item.statusCode] || statusConfig.waiting;
          return (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate('TrackingDetail', { trackId: item.id })}
              activeOpacity={0.85}
            >
              <View style={styles.cardTop}>
                <View style={[styles.statusBadge, { backgroundColor: cfg.bg }]}>
                  <Icon name={cfg.icon} size={14} color={cfg.color} />
                  <Text style={[styles.statusText, { color: cfg.color }]}>{item.status}</Text>
                </View>
                <Text style={styles.dateText}>{item.date}</Text>
              </View>

              <Text style={styles.trackId}>{item.id}</Text>

              <View style={styles.cardInfo}>
                <View style={styles.infoItem}>
                  <Icon name="map-marker-outline" size={14} color="#94A3B8" />
                  <Text style={styles.infoText}>{item.from}</Text>
                </View>
                <View style={styles.infoItem}>
                  <Icon name="weight" size={14} color="#94A3B8" />
                  <Text style={styles.infoText}>{item.weight}</Text>
                </View>
              </View>

              <View style={styles.progressContainer}>
                <View style={styles.progressBg}>
                  <View style={[styles.progressFill, {
                    width: `${item.progress}%`,
                    backgroundColor: cfg.color
                  }]} />
                </View>
                <Text style={[styles.progressPct, { color: cfg.color }]}>{item.progress}%</Text>
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Icon name="package-variant-closed-remove" size={48} color="#CBD5E1" />
            <Text style={styles.emptyText}>Bağlama tapılmadı</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: {
    paddingTop: 48,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 16 },
  searchRow: { flexDirection: 'row', gap: 10 },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  searchInput: { flex: 1, fontSize: 14, color: '#1E293B', height: 42, marginLeft: 8 },
  scanBtn: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 12,
    padding: 10,
    justifyContent: 'center',
  },
  list: { padding: 16 },
  listTitle: { fontSize: 16, fontWeight: '700', color: '#1E293B', marginBottom: 12 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, gap: 5 },
  statusText: { fontSize: 12, fontWeight: '700' },
  dateText: { fontSize: 12, color: '#94A3B8' },
  trackId: { fontSize: 17, fontWeight: '800', color: '#1E293B', marginBottom: 10, letterSpacing: 0.5 },
  cardInfo: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  infoItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  infoText: { fontSize: 12, color: '#64748B' },
  progressContainer: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  progressBg: { flex: 1, height: 6, backgroundColor: '#E2E8F0', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  progressPct: { fontSize: 12, fontWeight: '700', width: 36, textAlign: 'right' },
  empty: { alignItems: 'center', marginTop: 60, gap: 12 },
  emptyText: { color: '#94A3B8', fontSize: 15 },
});
