// src/screens/HomeScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, StatusBar, Dimensions,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const { width } = Dimensions.get('window');

const COLORS = {
  primary: '#1A3A5C',
  secondary: '#2563EB',
  accent: '#E63946',
  bg: '#F0F4F8',
  card: '#FFFFFF',
  text: '#1E293B',
  muted: '#64748B',
};

const quickActions = [
  { icon: 'package-variant-closed', label: 'Bağlama\nİzlə', color: '#2563EB', screen: 'Tracking' },
  { icon: 'map-marker-radius', label: 'Filial\nTap', color: '#059669', screen: 'Branches' },
  { icon: 'credit-card-fast', label: 'Ödəniş\nEt', color: '#7C3AED', screen: 'Payment' },
  { icon: 'robot-happy', label: 'AI\nKöməkçi', color: '#DC2626', screen: 'Chatbot' },
];

const recentPackages = [
  { id: 'AZ123456789', status: 'Çatdırılır', statusColor: '#059669', from: 'Çin', date: '25 Apr', progress: 75 },
  { id: 'AZ987654321', status: 'Gömrükdə', statusColor: '#D97706', from: 'Türkiyə', date: '23 Apr', progress: 45 },
  { id: 'AZ456789123', status: 'Çatdırıldı', statusColor: '#6B7280', from: 'ABŞ', date: '20 Apr', progress: 100 },
];

export default function HomeScreen({ navigation }) {
  const [trackInput, setTrackInput] = useState('');

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor={COLORS.primary} barStyle="light-content" />
      
      {/* Header */}
      <LinearGradient
        colors={['#1A3A5C', '#2563EB']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Salam! 👋</Text>
            <Text style={styles.headerTitle}>AzərPoçt</Text>
          </View>
          <TouchableOpacity style={styles.notifBtn}>
            <Icon name="bell-outline" size={24} color="#fff" />
            <View style={styles.notifDot} />
          </TouchableOpacity>
        </View>

        {/* Quick Track Input */}
        <View style={styles.trackBox}>
          <Icon name="barcode-scan" size={20} color={COLORS.muted} style={{ marginRight: 8 }} />
          <TextInput
            style={styles.trackInput}
            placeholder="İzləmə nömrəsini daxil edin..."
            placeholderTextColor={COLORS.muted}
            value={trackInput}
            onChangeText={setTrackInput}
            returnKeyType="search"
            onSubmitEditing={() => {
              if (trackInput.trim()) {
                navigation.navigate('Tracking', {
                  screen: 'TrackingDetail',
                  params: { trackId: trackInput.trim() }
                });
              }
            }}
          />
          <TouchableOpacity
            style={styles.trackBtn}
            onPress={() => {
              if (trackInput.trim()) {
                navigation.navigate('Tracking', {
                  screen: 'TrackingDetail',
                  params: { trackId: trackInput.trim() }
                });
              }
            }}
          >
            <Icon name="magnify" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView style={styles.body} showsVerticalScrollIndicator={false}>
        
        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Sürətli Əməliyyatlar</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((action, i) => (
            <TouchableOpacity
              key={i}
              style={styles.actionCard}
              onPress={() => navigation.navigate(action.screen)}
              activeOpacity={0.8}
            >
              <View style={[styles.actionIcon, { backgroundColor: action.color + '18' }]}>
                <Icon name={action.icon} size={28} color={action.color} />
              </View>
              <Text style={styles.actionLabel}>{action.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Recent Packages */}
        <View style={styles.sectionRow}>
          <Text style={styles.sectionTitle}>Son Bağlamalar</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Tracking')}>
            <Text style={styles.seeAll}>Hamısı →</Text>
          </TouchableOpacity>
        </View>

        {recentPackages.map((pkg, i) => (
          <TouchableOpacity
            key={i}
            style={styles.packageCard}
            onPress={() => navigation.navigate('Tracking', {
              screen: 'TrackingDetail',
              params: { trackId: pkg.id }
            })}
            activeOpacity={0.85}
          >
            <View style={styles.pkgLeft}>
              <View style={[styles.pkgIcon, { backgroundColor: pkg.statusColor + '15' }]}>
                <Icon name="package-variant-closed" size={22} color={pkg.statusColor} />
              </View>
              <View>
                <Text style={styles.pkgId}>{pkg.id}</Text>
                <Text style={styles.pkgFrom}>{pkg.from} · {pkg.date}</Text>
              </View>
            </View>
            <View style={styles.pkgRight}>
              <Text style={[styles.pkgStatus, { color: pkg.statusColor }]}>{pkg.status}</Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${pkg.progress}%`, backgroundColor: pkg.statusColor }]} />
              </View>
            </View>
          </TouchableOpacity>
        ))}

        {/* Banner */}
        <TouchableOpacity activeOpacity={0.9} style={{ marginBottom: 20 }}>
          <LinearGradient
            colors={['#7C3AED', '#4F46E5']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.banner}
          >
            <View>
              <Text style={styles.bannerTitle}>PostKargo</Text>
              <Text style={styles.bannerText}>Xarici alış-verişlərinizi\nasanlıqla çatdırın</Text>
            </View>
            <Icon name="arrow-right-circle" size={40} color="rgba(255,255,255,0.7)" />
          </LinearGradient>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: {
    paddingTop: 48,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { color: 'rgba(255,255,255,0.75)', fontSize: 13, fontWeight: '500' },
  headerTitle: { color: '#fff', fontSize: 26, fontWeight: '800', letterSpacing: -0.5 },
  notifBtn: { padding: 8, position: 'relative' },
  notifDot: { position: 'absolute', top: 8, right: 8, width: 8, height: 8, borderRadius: 4, backgroundColor: '#E63946' },
  trackBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 4,
    elevation: 4,
  },
  trackInput: { flex: 1, fontSize: 14, color: '#1E293B', height: 44 },
  trackBtn: {
    backgroundColor: '#E63946',
    borderRadius: 10,
    padding: 8,
  },
  body: { flex: 1, paddingHorizontal: 16 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: '#1E293B', marginTop: 20, marginBottom: 12 },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, marginBottom: 12 },
  seeAll: { color: '#2563EB', fontSize: 13, fontWeight: '600' },
  actionsGrid: { flexDirection: 'row', justifyContent: 'space-between' },
  actionCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    width: (width - 48) / 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
  },
  actionIcon: { borderRadius: 12, padding: 10, marginBottom: 8 },
  actionLabel: { fontSize: 11, color: '#374151', fontWeight: '600', textAlign: 'center', lineHeight: 15 },
  packageCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  pkgLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  pkgIcon: { borderRadius: 10, padding: 10, marginRight: 12 },
  pkgId: { fontSize: 13, fontWeight: '700', color: '#1E293B' },
  pkgFrom: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  pkgRight: { alignItems: 'flex-end' },
  pkgStatus: { fontSize: 12, fontWeight: '700', marginBottom: 6 },
  progressBar: { width: 70, height: 4, backgroundColor: '#E2E8F0', borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 2 },
  banner: {
    borderRadius: 18,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bannerTitle: { color: '#fff', fontSize: 18, fontWeight: '800', marginBottom: 4 },
  bannerText: { color: 'rgba(255,255,255,0.8)', fontSize: 13, lineHeight: 19 },
});
