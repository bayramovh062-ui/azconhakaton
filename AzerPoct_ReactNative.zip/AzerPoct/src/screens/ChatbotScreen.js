// src/screens/ChatbotScreen.js
import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const ANTHROPIC_API_KEY = 'YOUR_API_KEY_HERE'; // .env faylından oxuyun

const SYSTEM_PROMPT = `Sən AzərPoçtun AI köməkçisisən. Azərbaycan dilində cavab ver.
AzərPoçt haqqında məlumat:
- 1500+ filial var bütün Azərbaycanda
- Bağlama izləmə: sayta daxil ol və ya bu tətbiqdən istifadə et
- Xidmətlər: yerli/beynəlxalq çatdırılma, EMS, PostKargo, pul köçürmə, kommunal ödənişlər
- Çatdırılma müddəti: Bakı daxili 1-2 gün, regionlar 2-4 gün, beynəlxalq 7-30 gün
- Dəstək: 1655 (qaynar xətt)
Qısa, aydın və dostcasına cavab ver. Bilmədiklərini etiraf et.`;

const quickReplies = [
  'Bağlamam harada?',
  'Ən yaxın filial?',
  'Çatdırılma nə qədər tutur?',
  'Xarici alış-veriş?',
];

export default function ChatbotScreen() {
  const [messages, setMessages] = useState([
    {
      id: '0',
      role: 'assistant',
      text: 'Salam! Mən AzərPoçt AI Köməkçisiyəm 🤖\nSizə bağlama izləmə, filial tapma, tariflər və digər xidmətlər haqqında kömək edə bilərəm.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const flatRef = useRef(null);

  const sendMessage = useCallback(async (text) => {
    const userText = text || input.trim();
    if (!userText) return;

    const userMsg = { id: Date.now().toString(), role: 'user', text: userText };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const history = newMessages.map(m => ({
        role: m.role,
        content: m.text,
      }));

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 500,
          system: SYSTEM_PROMPT,
          messages: history,
        }),
      });

      const data = await response.json();
      const replyText = data.content?.[0]?.text || 'Bağışlayın, cavab verə bilmədim.';

      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'assistant', text: replyText },
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          text: 'İnternet bağlantısında problem var. Zəhmət olmasa yenidən cəhd edin.',
        },
      ]);
    } finally {
      setLoading(false);
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [input, messages]);

  const renderMessage = ({ item }) => {
    const isUser = item.role === 'user';
    return (
      <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
        {!isUser && (
          <View style={styles.avatar}>
            <Icon name="robot" size={16} color="#fff" />
          </View>
        )}
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleBot]}>
          <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>
            {item.text}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      {/* Header */}
      <LinearGradient colors={['#1A3A5C', '#2563EB']} style={styles.header}>
        <View style={styles.headerInfo}>
          <View style={styles.botAvatar}>
            <Icon name="robot" size={22} color="#fff" />
          </View>
          <View>
            <Text style={styles.botName}>AzərPoçt Köməkçisi</Text>
            <View style={styles.onlineRow}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>Aktivdir</Text>
            </View>
          </View>
        </View>
      </LinearGradient>

      {/* Messages */}
      <FlatList
        ref={flatRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={renderMessage}
        contentContainerStyle={styles.messageList}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: true })}
      />

      {/* Loading */}
      {loading && (
        <View style={styles.typingRow}>
          <View style={styles.avatar}>
            <Icon name="robot" size={16} color="#fff" />
          </View>
          <View style={styles.typingBubble}>
            <ActivityIndicator size="small" color="#2563EB" />
            <Text style={styles.typingText}>Yazır...</Text>
          </View>
        </View>
      )}

      {/* Quick Replies */}
      {messages.length <= 2 && (
        <View style={styles.quickReplies}>
          {quickReplies.map((q, i) => (
            <TouchableOpacity
              key={i}
              style={styles.quickBtn}
              onPress={() => sendMessage(q)}
            >
              <Text style={styles.quickBtnText}>{q}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Input */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Mesaj yazın..."
          placeholderTextColor="#94A3B8"
          value={input}
          onChangeText={setInput}
          multiline
          maxLength={500}
        />
        <TouchableOpacity
          style={[styles.sendBtn, { opacity: input.trim() ? 1 : 0.5 }]}
          onPress={() => sendMessage()}
          disabled={!input.trim() || loading}
        >
          <Icon name="send" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: {
    paddingTop: 48,
    paddingHorizontal: 20,
    paddingBottom: 18,
  },
  headerInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  botAvatar: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.25)',
    justifyContent: 'center', alignItems: 'center',
  },
  botName: { color: '#fff', fontSize: 16, fontWeight: '700' },
  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  onlineDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: '#4ADE80' },
  onlineText: { color: 'rgba(255,255,255,0.8)', fontSize: 12 },
  messageList: { padding: 16, gap: 10, paddingBottom: 8 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 8 },
  msgRowUser: { justifyContent: 'flex-end' },
  avatar: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: '#2563EB',
    justifyContent: 'center', alignItems: 'center',
  },
  bubble: {
    maxWidth: '78%', padding: 12, borderRadius: 16,
  },
  bubbleBot: {
    backgroundColor: '#fff',
    borderBottomLeftRadius: 4,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  bubbleUser: {
    backgroundColor: '#2563EB',
    borderBottomRightRadius: 4,
  },
  bubbleText: { fontSize: 14, color: '#1E293B', lineHeight: 20 },
  bubbleTextUser: { color: '#fff' },
  typingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, marginBottom: 4 },
  typingBubble: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#fff', padding: 10, borderRadius: 16,
    borderBottomLeftRadius: 4,
  },
  typingText: { color: '#94A3B8', fontSize: 13 },
  quickReplies: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 8,
    paddingHorizontal: 16, paddingBottom: 8,
  },
  quickBtn: {
    backgroundColor: '#fff', borderRadius: 20,
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1.5, borderColor: '#2563EB',
    elevation: 1,
  },
  quickBtnText: { color: '#2563EB', fontSize: 13, fontWeight: '600' },
  inputRow: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 10,
    padding: 12, backgroundColor: '#fff',
    borderTopWidth: 1, borderTopColor: '#F1F5F9',
    elevation: 8,
  },
  input: {
    flex: 1, backgroundColor: '#F8FAFC', borderRadius: 22,
    paddingHorizontal: 16, paddingVertical: 10,
    fontSize: 14, color: '#1E293B', maxHeight: 100,
    borderWidth: 1, borderColor: '#E2E8F0',
  },
  sendBtn: {
    backgroundColor: '#2563EB', borderRadius: 22,
    width: 44, height: 44, justifyContent: 'center', alignItems: 'center',
  },
});
