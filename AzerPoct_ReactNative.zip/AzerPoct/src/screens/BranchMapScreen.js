// src/screens/BranchMapScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  FlatList, Linking,
} from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const branches = [
  {
    id: 1, name: 'Baş Poçt Kantoru', district: 'Səbail',
    address: 'Üzeyir Hacıbəyov küç. 33',
    hours: 'B.e–C.: 09:00–18:00',
    phone: '+994 12 493 53 67',
    lat: 40.3698, lng: 49.8340,
    services: ['Bağlama', 'EMS', 'Ödəniş', 'PostKargo'],
    rating: 4.2,
  },
  {
    id: 2, name: 'Nizami Filialı', district: 'Nizami',
    address: 'Nizami küç. 128',
    hours: 'B.e–C.: 09:00–19:00',
    phone: '+994 12 598 22 14',
    lat: 40.3789, lng: 49.8524,
    services: ['Bağlama', 'Ödəniş', 'Pul köçürmə'],
    rating: 3.9,
  },
  {
    id: 3, name: 'Nərimanov Filialı', district: 'Nərimanov',
    address: 'Atatürk pr. 45',
    hours: 'B.e–C.: 09:00–18:00',
    phone: '+994 12 562 17 89',
    lat: 40.4125, lng: 49.8671,
    services: ['Bağlama', 'EMS', 'Ödəniş'],
    rating: 4.5,
  },
  {
    id: 4, name: 'Yasamal Filialı', district: 'Yasamal',
    address: 'Rəşid Behbudov küç. 77',
    hours: 'B.e–C.: 09:00–18:00',
    phone: '+994 12 441 35 22',
    lat: 40.3912, lng: 49.8103,
    services: ['Bağlama', 'Ödəniş'],
    rating: 4.0,
  },
  {
    id: 5, name: 'Binəqədi Filialı', district: 'Binəqədi',
    address: 'Binəqədi şossesi 12',
    hours: 'B.e–C.: 09:00–17:00',
    phone: '+994 12 449 11 03',
    lat: 40.4289, lng: 49.7932,
    services: ['Bağlama', 'Ödəniş'],
    rating: 3.7,
  },
];

export default function BranchMapScreen() {
  const [query, setQuery] = useState('');
  const [view, setView] = useState('list'); // 'list' | 'map'
  const [selected, setSelected] = useState(null);

  const filtered = branches.filter(b =>
    b.name.toLowerCase().includes(query.toLowerCase()) ||
    b.district.toLowerCase().includes(query.toLowerCase()) ||
    b.address.toLowerCase().includes(query.toLowerCase())
  );

  const openMaps = (branch) => {
    const url = `https://maps.google.com/?q=${branch.lat},${branch.lng}`;
    Linking.openURL(url);
  };

  const renderBranch = ({ item }) => (
    <TouchableOpacity
      style={[styles.branchCard, selected?.id === item.id && styles.branchCardSelected]}
      onPress={() => setSelected(item)}
      activeOpacity={0.85}
    >
      <View style={styles.branchTop}>
        <View>
          <Text style={styles.branchName}>{item.name}</Text>
          <Text style={styles.branchDistrict}>{item.district} r-nu</Text>
        </View>
        <View style={styles.ratingBadge}>
          <Icon name="star" size={12} color="#F59E0B" />
          <Text style={styles.ratingText}>{item.rating}</Text>
        </View>
      </View>

      <View style={styles.branchInfo}>
        <Icon name="map-marker-outline" size={14} color="#94A3B8" />
        <Text style={styles.branchAddress}>{item.address}</Text>
      </View>
      <View style={styles.branchInfo}>
        <Icon name="clock-outline" size={14} color="#94A3B8" />
        <Text style={styles.branchAddress}>{item.hours}</Text>
      </View>

      <View style={styles.servicesList}>
        {item.services.slice(0, 3).map((s, i) => (
          <View key={i} style={styles.serviceTag}>
            <Text style={styles.serviceTagText}>{s}</Text>
          </View>
        ))}
        {item.services.length > 3 && (
          <Text style={styles.moreServices}>+{item.services.length - 3}</Text>
        )}
      </View>

      {selected?.id === item.id && (
        <View style={styles.branchActions}>
          <TouchableOpacity
            style={styles.branchActionBtn}
            onPress={() => Linking.openURL(`tel:${item.phone}`)}
          >
            <Icon name="phone" size={16} color="#2563EB" />
            <Text style={styles.branchActionText}>Zəng et</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.branchActionBtn, { backgroundColor: '#2563EB' }]}
            onPress={() => openMaps(item)}
          >
            <Icon name="navigation" size={16} color="#fff" />
            <Text style={[styles.branchActionText, { color: '#fff' }]}>Yol al</Text>
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1A3A5C', '#2563EB']} style={styles.header}>
        <Text style={styles.headerTitle}>Filiallar</Text>
        <View style={styles.topRow}>
          <View style={styles.searchBox}>
            <Icon name="magnify" size={18} color="#94A3B8" />
            <TextInput
              style={styles.searchInput}
              placeholder="Filial axtar..."
              placeholderTextColor="#94A3B8"
              value={query}
              onChangeText={setQuery}
            />
          </View>
          <View style={styles.viewToggle}>
            <TouchableOpacity
              style={[styles.toggleBtn, view === 'list' && styles.toggleBtnActive]}
              onPress={() => setView('list')}
            >
              <Icon name="format-list-bulleted" size={18} color={view === 'list' ? '#2563EB' : '#94A3B8'} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleBtn, view === 'map' && styles.toggleBtnActive]}
              onPress={() => setView('map')}
            >
              <Icon name="map" size={18} color={view === 'map' ? '#2563EB' : '#94A3B8'} />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      {view === 'map' ? (
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: 40.3893,
              longitude: 49.8390,
              latitudeDelta: 0.15,
              longitudeDelta: 0.15,
            }}
          >
            {filtered.map(branch => (
              <Marker
                key={branch.id}
                coordinate={{ latitude: branch.lat, longitude: branch.lng }}
                onPress={() => setSelected(branch)}
              >
                <View style={[styles.mapPin, selected?.id === branch.id && styles.mapPinSelected]}>
                  <Icon name="post-outline" size={16} color="#fff" />
                </View>
                <Callout>
                  <View style={styles.callout}>
                    <Text style={styles.calloutName}>{branch.name}</Text>
                    <Text style={styles.calloutAddr}>{branch.address}</Text>
                  </View>
                </Callout>
              </Marker>
            ))}
          </MapView>

          {selected && (
            <View style={styles.mapCard}>
              <Text style={styles.branchName}>{selected.name}</Text>
              <Text style={styles.branchAddress}>{selected.address}</Text>
              <View style={styles.branchActions}>
                <TouchableOpacity
                  style={styles.branchActionBtn}
                  onPress={() => Linking.openURL(`tel:${selected.phone}`)}
                >
                  <Icon name="phone" size={16} color="#2563EB" />
                  <Text style={styles.branchActionText}>Zəng et</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.branchActionBtn, { backgroundColor: '#2563EB' }]}
                  onPress={() => openMaps(selected)}
                >
                  <Icon name="navigation" size={16} color="#fff" />
                  <Text style={[styles.branchActionText, { color: '#fff' }]}>Yol al</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id.toString()}
          renderItem={renderBranch}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.listCount}>{filtered.length} filial tapıldı</Text>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: { paddingTop: 48, paddingHorizontal: 20, paddingBottom: 16 },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 14 },
  topRow: { flexDirection: 'row', gap: 10 },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 12,
  },
  searchInput: { flex: 1, fontSize: 14, color: '#1E293B', height: 42, marginLeft: 6 },
  viewToggle: {
    flexDirection: 'row', backgroundColor: '#fff',
    borderRadius: 12, overflow: 'hidden',
  },
  toggleBtn: { padding: 10, paddingHorizontal: 12 },
  toggleBtnActive: { backgroundColor: '#EFF6FF' },
  list: { padding: 16 },
  listCount: { fontSize: 13, color: '#64748B', marginBottom: 12 },
  branchCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 16,
    marginBottom: 12, elevation: 2, borderWidth: 1.5, borderColor: 'transparent',
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4,
  },
  branchCardSelected: { borderColor: '#2563EB' },
  branchTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  branchName: { fontSize: 15, fontWeight: '700', color: '#1E293B' },
  branchDistrict: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  ratingBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10,
  },
  ratingText: { fontSize: 12, color: '#92400E', fontWeight: '700' },
  branchInfo: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 5 },
  branchAddress: { fontSize: 12, color: '#64748B', flex: 1 },
  servicesList: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 },
  serviceTag: {
    backgroundColor: '#EFF6FF', borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  serviceTagText: { fontSize: 11, color: '#2563EB', fontWeight: '600' },
  moreServices: { fontSize: 11, color: '#94A3B8', alignSelf: 'center' },
  branchActions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  branchActionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10, borderRadius: 12,
    borderWidth: 1.5, borderColor: '#2563EB',
  },
  branchActionText: { color: '#2563EB', fontWeight: '700', fontSize: 13 },
  mapContainer: { flex: 1 },
  map: { flex: 1 },
  mapPin: {
    backgroundColor: '#2563EB', borderRadius: 20, padding: 8,
    elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2, shadowRadius: 4,
  },
  mapPinSelected: { backgroundColor: '#E63946', transform: [{ scale: 1.2 }] },
  callout: { padding: 8, maxWidth: 180 },
  calloutName: { fontSize: 13, fontWeight: '700', color: '#1E293B' },
  calloutAddr: { fontSize: 11, color: '#64748B', marginTop: 3 },
  mapCard: {
    position: 'absolute', bottom: 20, left: 16, right: 16,
    backgroundColor: '#fff', borderRadius: 18, padding: 18, elevation: 8,
  },
});
