// src/screens/PaymentScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import QRCode from 'react-native-qrcode-svg';

const paymentCategories = [
  {
    title: 'Kommunal',
    icon: 'lightning-bolt',
    color: '#F59E0B',
    items: ['Elektrik (Azərenerji)', 'Qaz (SOCAR)', 'Su (Azərsu)', 'İstilik'],
  },
  {
    title: 'Mobil',
    icon: 'cellphone',
    color: '#8B5CF6',
    items: ['Azercell', 'Bakcell', 'Nar Mobile', 'Naxtel'],
  },
  {
    title: 'İnternet / TV',
    icon: 'wifi',
    color: '#06B6D4',
    items: ['Aztelekom', 'Catel', 'Delta Telecom', 'AzSat'],
  },
  {
    title: 'Pul Köçürmə',
    icon: 'bank-transfer',
    color: '#10B981',
    items: ['Yerli köçürmə', 'Beynəlxalq', 'Bölgülərə', 'Zibil ödənişi'],
  },
];

export default function PaymentScreen() {
  const [activeTab, setActiveTab] = useState('services');
  const [selectedService, setSelectedService] = useState(null);
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [showQR, setShowQR] = useState(false);

  const handlePay = () => {
    if (accountNumber && amount) {
      setShowQR(true);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1A3A5C', '#2563EB']} style={styles.header}>
        <Text style={styles.headerTitle}>Ödəniş & Köçürmə</Text>
        <View style={styles.tabs}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'services' && styles.tabActive]}
            onPress={() => setActiveTab('services')}
          >
            <Text style={[styles.tabText, activeTab === 'services' && styles.tabTextActive]}>
              Xidmətlər
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'history' && styles.tabActive]}
            onPress={() => setActiveTab('history')}
          >
            <Text style={[styles.tabText, activeTab === 'history' && styles.tabTextActive]}>
              Tarixçə
            </Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView style={styles.body} showsVerticalScrollIndicator={false}>
        {activeTab === 'services' && (
          <>
            {!selectedService ? (
              <>
                {/* Balance Card */}
                <LinearGradient colors={['#7C3AED', '#4F46E5']} style={styles.balanceCard}>
                  <Text style={styles.balanceLabel}>AzərPoçt Kart Balansı</Text>
                  <Text style={styles.balanceAmount}>245.80 ₼</Text>
                  <View style={styles.cardRow}>
                    <Text style={styles.cardNumber}>**** **** **** 4521</Text>
                    <Icon name="contactless-payment" size={28} color="rgba(255,255,255,0.6)" />
                  </View>
                </LinearGradient>

                {/* Categories */}
                {paymentCategories.map((cat, i) => (
                  <View key={i} style={styles.categoryBlock}>
                    <View style={styles.categoryHeader}>
                      <View style={[styles.catIcon, { backgroundColor: cat.color + '18' }]}>
                        <Icon name={cat.icon} size={18} color={cat.color} />
                      </View>
                      <Text style={styles.categoryTitle}>{cat.title}</Text>
                    </View>
                    <View style={styles.servicesGrid}>
                      {cat.items.map((item, j) => (
                        <TouchableOpacity
                          key={j}
                          style={styles.serviceBtn}
                          onPress={() => setSelectedService({ category: cat.title, name: item, color: cat.color })}
                        >
                          <Text style={styles.serviceBtnText}>{item}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                ))}
              </>
            ) : (
              /* Payment Form */
              <View style={styles.paymentForm}>
                <TouchableOpacity
                  style={styles.backRow}
                  onPress={() => { setSelectedService(null); setShowQR(false); setAccountNumber(''); setAmount(''); }}
                >
                  <Icon name="arrow-left" size={20} color="#2563EB" />
                  <Text style={styles.backRowText}>Geri</Text>
                </TouchableOpacity>

                <Text style={styles.formTitle}>{selectedService.name}</Text>
                <Text style={styles.formSubtitle}>{selectedService.category}</Text>

                {!showQR ? (
                  <>
                    <View style={styles.inputBlock}>
                      <Text style={styles.inputLabel}>Hesab nömrəsi / Abunə №</Text>
                      <TextInput
                        style={styles.formInput}
                        placeholder="Məs: 00123456789"
                        placeholderTextColor="#94A3B8"
                        value={accountNumber}
                        onChangeText={setAccountNumber}
                        keyboardType="numeric"
                      />
                    </View>
                    <View style={styles.inputBlock}>
                      <Text style={styles.inputLabel}>Məbləğ (₼)</Text>
                      <TextInput
                        style={styles.formInput}
                        placeholder="0.00"
                        placeholderTextColor="#94A3B8"
                        value={amount}
                        onChangeText={setAmount}
                        keyboardType="decimal-pad"
                      />
                    </View>
                    <View style={styles.quickAmounts}>
                      {['10', '20', '50', '100'].map(a => (
                        <TouchableOpacity
                          key={a}
                          style={styles.quickAmount}
                          onPress={() => setAmount(a)}
                        >
                          <Text style={styles.quickAmountText}>{a} ₼</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                    <TouchableOpacity
                      style={[styles.payBtn, { opacity: accountNumber && amount ? 1 : 0.5 }]}
                      onPress={handlePay}
                      disabled={!accountNumber || !amount}
                    >
                      <LinearGradient colors={['#2563EB', '#1D4ED8']} style={styles.payBtnGrad}>
                        <Icon name="credit-card-check" size={20} color="#fff" />
                        <Text style={styles.payBtnText}>Ödəniş Et — {amount ? amount + ' ₼' : ''}</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  </>
                ) : (
                  /* QR Code Confirmation */
                  <View style={styles.qrBlock}>
                    <Text style={styles.qrTitle}>Ödənişi Təsdiq Et</Text>
                    <Text style={styles.qrSubtitle}>QR kodu kassa terminalına tutun</Text>
                    <View style={styles.qrContainer}>
                      <QRCode
                        value={`AZPOST|${selectedService.name}|${accountNumber}|${amount}AZN`}
                        size={200}
                        color="#1A3A5C"
                        backgroundColor="#fff"
                      />
                    </View>
                    <View style={styles.qrInfo}>
                      <Text style={styles.qrInfoLabel}>Xidmət: <Text style={styles.qrInfoValue}>{selectedService.name}</Text></Text>
                      <Text style={styles.qrInfoLabel}>Hesab: <Text style={styles.qrInfoValue}>{accountNumber}</Text></Text>
                      <Text style={styles.qrInfoLabel}>Məbləğ: <Text style={[styles.qrInfoValue, { color: '#059669' }]}>{amount} ₼</Text></Text>
                    </View>
                    <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowQR(false)}>
                      <Text style={styles.cancelBtnText}>Ləğv et</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            )}
          </>
        )}

        {activeTab === 'history' && (
          <View style={styles.historyList}>
            {[
              { name: 'Azərenerji', amount: '-45.20 ₼', date: '24 Apr', status: 'Uğurlu', color: '#059669' },
              { name: 'Azercell', amount: '-20.00 ₼', date: '22 Apr', status: 'Uğurlu', color: '#059669' },
              { name: 'SOCAR Qaz', amount: '-68.50 ₼', date: '18 Apr', status: 'Uğurlu', color: '#059669' },
            ].map((h, i) => (
              <View key={i} style={styles.historyItem}>
                <View style={styles.historyLeft}>
                  <Icon name="receipt" size={20} color="#2563EB" />
                  <View>
                    <Text style={styles.historyName}>{h.name}</Text>
                    <Text style={styles.historyDate}>{h.date}</Text>
                  </View>
                </View>
                <View style={styles.historyRight}>
                  <Text style={styles.historyAmount}>{h.amount}</Text>
                  <Text style={[styles.historyStatus, { color: h.color }]}>{h.status}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4F8' },
  header: { paddingTop: 48, paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800', marginBottom: 16 },
  tabs: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 12, padding: 4 },
  tab: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 9 },
  tabActive: { backgroundColor: '#fff' },
  tabText: { color: 'rgba(255,255,255,0.7)', fontWeight: '600', fontSize: 14 },
  tabTextActive: { color: '#2563EB' },
  body: { flex: 1, padding: 16 },
  balanceCard: { borderRadius: 20, padding: 22, marginBottom: 20 },
  balanceLabel: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginBottom: 6 },
  balanceAmount: { color: '#fff', fontSize: 34, fontWeight: '800', marginBottom: 16 },
  cardRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardNumber: { color: 'rgba(255,255,255,0.8)', fontSize: 15, letterSpacing: 2 },
  categoryBlock: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2 },
  categoryHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  catIcon: { padding: 8, borderRadius: 10 },
  categoryTitle: { fontSize: 15, fontWeight: '700', color: '#1E293B' },
  servicesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  serviceBtn: {
    backgroundColor: '#F8FAFC', borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 8,
    borderWidth: 1, borderColor: '#E2E8F0',
  },
  serviceBtnText: { fontSize: 13, color: '#374151', fontWeight: '500' },
  paymentForm: { backgroundColor: '#fff', borderRadius: 20, padding: 20, elevation: 2 },
  backRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 16 },
  backRowText: { color: '#2563EB', fontWeight: '600' },
  formTitle: { fontSize: 22, fontWeight: '800', color: '#1E293B', marginBottom: 4 },
  formSubtitle: { fontSize: 13, color: '#94A3B8', marginBottom: 20 },
  inputBlock: { marginBottom: 16 },
  inputLabel: { fontSize: 13, color: '#64748B', fontWeight: '600', marginBottom: 8 },
  formInput: {
    borderWidth: 1.5, borderColor: '#E2E8F0', borderRadius: 12,
    padding: 14, fontSize: 15, color: '#1E293B', backgroundColor: '#F8FAFC',
  },
  quickAmounts: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  quickAmount: {
    flex: 1, borderWidth: 1.5, borderColor: '#2563EB',
    borderRadius: 10, paddingVertical: 10, alignItems: 'center',
  },
  quickAmountText: { color: '#2563EB', fontWeight: '700', fontSize: 14 },
  payBtn: { borderRadius: 14, overflow: 'hidden' },
  payBtnGrad: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 16 },
  payBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  qrBlock: { alignItems: 'center' },
  qrTitle: { fontSize: 18, fontWeight: '800', color: '#1E293B', marginBottom: 6 },
  qrSubtitle: { fontSize: 13, color: '#94A3B8', marginBottom: 24 },
  qrContainer: {
    padding: 24, backgroundColor: '#fff', borderRadius: 20,
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1, shadowRadius: 8, marginBottom: 20,
  },
  qrInfo: { width: '100%', gap: 8, marginBottom: 20 },
  qrInfoLabel: { fontSize: 14, color: '#64748B' },
  qrInfoValue: { color: '#1E293B', fontWeight: '700' },
  cancelBtn: {
    borderWidth: 1.5, borderColor: '#E63946', borderRadius: 12,
    paddingVertical: 12, paddingHorizontal: 32,
  },
  cancelBtnText: { color: '#E63946', fontWeight: '700', fontSize: 14 },
  historyList: { gap: 10 },
  historyItem: {
    backgroundColor: '#fff', borderRadius: 14, padding: 16,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    elevation: 2,
  },
  historyLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  historyName: { fontSize: 14, fontWeight: '700', color: '#1E293B' },
  historyDate: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  historyRight: { alignItems: 'flex-end' },
  historyAmount: { fontSize: 15, fontWeight: '800', color: '#1E293B' },
  historyStatus: { fontSize: 12, fontWeight: '600', marginTop: 2 },
});
