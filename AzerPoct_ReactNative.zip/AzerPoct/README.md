# 📦 AzərPoçt Mobil Tətbiqi
**React Native** ilə yazılmış tam funksional AzərPoçt tətbiqi

---

## 🛠️ Quraşdırma (Setup)

### Tələblər
- Node.js 18+
- React Native CLI
- Android Studio (Android üçün)
- Xcode (iOS üçün, Mac lazımdır)

### Addımlar

```bash
# 1. Layihəni qur
npx react-native init AzerPoct
cd AzerPoct

# 2. Bütün faylları köçür (bu layihədən)

# 3. Asılılıqları yüklə
npm install

# 4. Android üçün vector icons qur
npx react-native link react-native-vector-icons

# 5. Tətbiqi başlat
npx react-native run-android
```

---

## 📱 Funksiyalar

| Ekran | Funksiya |
|-------|----------|
| 🏠 Ana Səhifə | Sürətli izləmə, son bağlamalar, banner |
| 📦 Bağlama İzlə | Real-time tracking, barcode skan, timeline |
| 🤖 AI Köməkçi | Claude AI ilə Azərbaycanca chatbot |
| 💳 Ödəniş | Kommunal, mobil, bank, QR kodla ödəniş |
| 🗺️ Filiallar | Xəritə + siyahı, yol göstərici, zəng |

---

## ⚙️ AI Chatbot Quraşdırması

`src/screens/ChatbotScreen.js` faylında API key əlavə et:

```javascript
const ANTHROPIC_API_KEY = 'sk-ant-XXXXXXXX'; // Öz açarını yaz
```

API key almaq üçün: https://console.anthropic.com

---

## 🎨 Rəng Palitası

```
Ana Rəng:    #1A3A5C (Tünd mavi)
İkincil:     #2563EB (Parlaq mavi)
Accent:      #E63946 (Qırmızı)
Arxa plan:   #F0F4F8 (Açıq boz)
```

---

## 📂 Fayl Strukturu

```
AzerPoct/
├── App.js                    # Ana navigasiya
├── src/
│   └── screens/
│       ├── HomeScreen.js         # Ana səhifə
│       ├── TrackingScreen.js     # Bağlama siyahısı
│       ├── TrackingDetailScreen.js # Bağlama detalları
│       ├── ChatbotScreen.js      # AI Köməkçi
│       ├── PaymentScreen.js      # Ödəniş
│       └── BranchMapScreen.js    # Filiallar xəritəsi
└── package.json
```

---

## 🚀 Hackaton üçün Qeydlər

Real AzərPoçt API mövcud olmadığı üçün hər yerdə **mock data** istifadə edilib.
Real tətbiqdə bunları əvəz etmək lazımdır:
- `mockPackages` → AzərPoçt tracking API
- `branches` → Real filial database
- AI chatbot → `.env` faylından API key

---

## 📞 Dəstək
AzərPoçt qaynar xətti: **1655**
